"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZSfPopover = exports.ZSfInputMessage = exports.ZSfIcon = exports.ZSfButton = exports.ZOtp = exports.ZMyzCardInfo = exports.ZMyzCardHeader = exports.ZMyzCardFooterSections = exports.ZMyzCardDictionary = exports.ZMyzCardCover = exports.ZMyzCardBody = exports.ZMyzCard = exports.ZAlert = void 0;
/* eslint-disable */
/* tslint:disable */
/* auto-generated react proxies */
const react_component_lib_1 = require("./react-component-lib");
exports.ZAlert = (0, react_component_lib_1.createReactComponent)('z-alert');
exports.ZMyzCard = (0, react_component_lib_1.createReactComponent)('z-myz-card');
exports.ZMyzCardBody = (0, react_component_lib_1.createReactComponent)('z-myz-card-body');
exports.ZMyzCardCover = (0, react_component_lib_1.createReactComponent)('z-myz-card-cover');
exports.ZMyzCardDictionary = (0, react_component_lib_1.createReactComponent)('z-myz-card-dictionary');
exports.ZMyzCardFooterSections = (0, react_component_lib_1.createReactComponent)('z-myz-card-footer-sections');
exports.ZMyzCardHeader = (0, react_component_lib_1.createReactComponent)('z-myz-card-header');
exports.ZMyzCardInfo = (0, react_component_lib_1.createReactComponent)('z-myz-card-info');
exports.ZOtp = (0, react_component_lib_1.createReactComponent)('z-otp');
exports.ZSfButton = (0, react_component_lib_1.createReactComponent)('z-sf-button');
exports.ZSfIcon = (0, react_component_lib_1.createReactComponent)('z-sf-icon');
exports.ZSfInputMessage = (0, react_component_lib_1.createReactComponent)('z-sf-input-message');
exports.ZSfPopover = (0, react_component_lib_1.createReactComponent)('z-sf-popover');
